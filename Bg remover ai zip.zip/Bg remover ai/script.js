document.addEventListener('DOMContentLoaded', () => {
    // --- IMPORTANT ---
    // Replace 'YOUR_API_KEY_HERE' with your actual remove.bg API key.
    const apiKey = 'PTBRCirgsVDMD6hR9KYhFrbu';
    // --- IMPORTANT ---
    
    // Get references to the HTML elements
    const imageInput = document.getElementById('imageInput');
    const removeBgBtn = document.getElementById('removeBgBtn');
    const originalImage = document.getElementById('originalImage');
    const resultImage = document.getElementById('resultImage');
    const loader = document.getElementById('loader');

    let imageFile = null;

    // Listen for file selection and display a preview of the original image
    imageInput.addEventListener('change', (event) => {
        imageFile = event.target.files[0];
        if (imageFile) {
            const reader = new FileReader();
            reader.onload = (e) => {
                originalImage.src = e.target.result;
                originalImage.style.display = 'block';
            };
            reader.readAsDataURL(imageFile);
        }
    });

    // Listen for the button click to start the background removal process
    removeBgBtn.addEventListener('click', () => {
        if (!imageFile) {
            alert('Please choose an image first.');
            return;
        }
        
        if (apiKey === 'YOUR_API_KEY_HERE') {
            alert('Please replace "YOUR_API_KEY_HERE" with your actual remove.bg API key in script.js');
            return;
        }

        // Prepare the data to send to the API
        const formData = new FormData();
        formData.append('image_file', imageFile);
        formData.append('size', 'auto'); // 'auto' is the default, can be 'preview', 'hd', etc.

        // Show loader and hide previous result
        loader.style.display = 'block';
        resultImage.style.display = 'none';
        
        // Make the API call using fetch
        fetch('https://api.remove.bg/v1.0/removebg', {
            method: 'POST',
            headers: {
                'X-Api-Key': apiKey,
            },
            body: formData,
        })
        .then(response => {
            if (!response.ok) {
                // If the response is not ok, read the error message
                return response.json().then(error => {
                    throw new Error(JSON.stringify(error));
                });
            }
            // If successful, the response is the image file itself (a blob)
            return response.blob();
        })
        .then(blob => {
            // Convert the blob to a URL and display the result image
            const url = URL.createObjectURL(blob);
            resultImage.src = url;
            resultImage.style.display = 'block';
        })
        .catch(error => {
            console.error('Error:', error);
            alert(`Failed to remove background. Error: ${error.message}`);
        })
        .finally(() => {
            // Hide loader regardless of success or failure
            loader.style.display = 'none';
        });
    });
});